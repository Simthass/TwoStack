"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";

const EXPO_EASE = [0.76, 0, 0.24, 1] as const;

export default function PageLoader() {
  const [loading, setLoading] = useState(true);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    // Only play the intro once per browser session, not on every
    // client-side route change (the component lives in the root
    // layout, so this effect only fires on a hard page load).
    const seen = sessionStorage.getItem("twostack-intro-played");
    if (seen) {
      setLoading(false);
      return;
    }

    setMounted(true);
    const timer = setTimeout(() => {
      setLoading(false);
      sessionStorage.setItem("twostack-intro-played", "1");
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  if (!mounted && !loading) return null;

  return (
    <AnimatePresence mode="wait">
      {loading && (
        <motion.div
          key="loader"
          initial={{ y: 0 }}
          exit={{ y: "-100%" }}
          transition={{ duration: 0.8, ease: EXPO_EASE }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-black"
        >
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="flex items-center gap-2.5"
          >
            <img
              src="/images/logo.png"
              alt=""
              width={22}
              height={22}
              className="object-contain brightness-0 invert"
            />
            <span className="font-satoshi font-bold text-[15px] tracking-[0.14em] uppercase text-white">
              TwoStack
            </span>
          </motion.div>

          <div className="mt-7 h-[1.5px] w-[140px] overflow-hidden rounded-full bg-white/10">
            <motion.div
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ duration: 1.0, ease: EXPO_EASE, delay: 0.15 }}
              style={{ transformOrigin: "left" }}
              className="h-full w-full bg-white"
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
